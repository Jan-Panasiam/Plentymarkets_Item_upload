# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['item_upload', 'item_upload.packages', 'item_upload.packages.gui']

package_data = \
{'': ['*'], 'item_upload.packages': ['gfx/*']}

install_requires = \
['chardet>=4.0.0,<5.0.0',
 'loguru>=0.5.3,<0.6.0',
 'openpyxl>=3.0.6,<4.0.0',
 'pandas>=1.2.1,<2.0.0']

setup_kwargs = {
    'name': 'item-upload',
    'version': '0.0.0',
    'description': 'Upload items to Plentymarkets from an Amazon Flatfile.',
    'long_description': None,
    'author': 'Sebastian Fricke',
    'author_email': 'sebastian.fricke@panasiam.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0.0',
}


setup(**setup_kwargs)
